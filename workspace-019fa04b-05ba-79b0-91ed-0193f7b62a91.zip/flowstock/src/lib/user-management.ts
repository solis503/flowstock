'use client'

import { createClient } from '@/lib/supabase-client'
import type { UserRole } from '@/lib/permissions'

const supabase = createClient()

export async function getUserRole(businessId: string): Promise<{ role: UserRole; fullName: string }> {
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return { role: 'none', fullName: '' }

  // Verificar si es owner
  const { data: business } = await supabase
    .from('businesses')
    .select('owner_id')
    .eq('id', businessId)
    .single()

  if (business?.owner_id === user.id) {
    return { role: 'owner', fullName: user.email || '' }
  }

  // Verificar perfil
  const { data: profile } = await supabase
    .from('profiles')
    .select('role, full_name')
    .eq('user_id', user.id)
    .eq('business_id', businessId)
    .eq('active', true)
    .single()

  if (profile) {
    return { role: profile.role as UserRole, fullName: profile.full_name || user.email || '' }
  }

  return { role: 'none', fullName: '' }
}

export async function getAllProfiles(businessId: string) {
  const { data } = await supabase
    .from('profiles')
    .select('*')
    .eq('business_id', businessId)
    .order('created_at')
  return data || []
}

export async function inviteUser(businessId: string, email: string, role: UserRole, fullName: string) {
  // Primero verificar si el usuario existe en auth
  // Si no existe, lo registramos con una contraseña temporal
  const tempPassword = Math.random().toString(36).slice(-10) + 'A1!'

  const { data: authData, error: authError } = await supabase.auth.signUp({
    email,
    password: tempPassword,
  })

  if (authError && !authError.message.includes('already')) {
    return { error: authError.message }
  }

  const userId = authData.user?.id
  if (!userId) {
    // El usuario ya existe, buscar su ID
    const { data: existingProfile } = await supabase
      .from('profiles')
      .select('user_id')
      .eq('business_id', businessId)
      .eq('email', email)
      .single()

    if (existingProfile) {
      // Actualizar rol
      await supabase.from('profiles').update({ role, active: true }).eq('user_id', existingProfile.user_id).eq('business_id', businessId)
      return { error: null }
    }

    return { error: 'No se encontró el usuario. Pídele que se registre primero.' }
  }

  // Crear perfil
  const { error } = await supabase.from('profiles').insert({
    user_id: userId,
    business_id: businessId,
    role,
    full_name: fullName,
    email,
    active: true,
  })

  if (error) {
    // Si el perfil ya existe, actualizar
    if (error.message?.includes('duplicate') || error.code === '23505') {
      await supabase.from('profiles').update({ role, active: true, full_name: fullName }).eq('user_id', userId).eq('business_id', businessId)
      return { error: null }
    }
    return { error: error.message }
  }

  return { error: null }
}

export async function toggleUserActive(profileId: string, active: boolean) {
  const { error } = await supabase.from('profiles').update({ active }).eq('id', profileId)
  return { error: error?.message || null }
}

export async function updateUserRole(profileId: string, role: UserRole) {
  const { error } = await supabase.from('profiles').update({ role }).eq('id', profileId)
  return { error: error?.message || null }
}

export async function removeUser(profileId: string) {
  const { error } = await supabase.from('profiles').delete().eq('id', profileId)
  return { error: error?.message || null }
}
