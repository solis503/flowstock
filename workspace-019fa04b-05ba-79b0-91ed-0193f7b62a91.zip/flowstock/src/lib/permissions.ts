// =====================================================
// FLOWSTOCK - Sistema de Permisos por Rol
// =====================================================
// owner: Acceso total (todo)
// manager: Todo excepto configuración del negocio y gestión de usuarios
// seller: Solo punto de venta y ver productos/inventario
// =====================================================

export type UserRole = 'owner' | 'manager' | 'seller' | 'none'

export interface Permissions {
  canViewDashboard: boolean
  canViewProducts: boolean
  canCreateEditProducts: boolean
  canDeleteProducts: boolean
  canUsePOS: boolean
  canViewInventory: boolean
  canModifyInventory: boolean
  canImportInventory: boolean
  canViewReports: boolean
  canViewSuppliers: boolean
  canViewExpenses: boolean
  canViewClients: boolean
  canViewSettings: boolean
  canEditSettings: boolean
  canManageUsers: boolean
  canViewSalesHistory: boolean
}

export function getPermissions(role: UserRole): Permissions {
  switch (role) {
    case 'owner':
      return {
        canViewDashboard: true, canViewProducts: true, canCreateEditProducts: true, canDeleteProducts: true,
        canUsePOS: true, canViewInventory: true, canModifyInventory: true, canImportInventory: true,
        canViewReports: true, canViewSuppliers: true, canViewExpenses: true, canViewClients: true,
        canViewSettings: true, canEditSettings: true, canManageUsers: true, canViewSalesHistory: true,
      }
    case 'manager':
      return {
        canViewDashboard: true, canViewProducts: true, canCreateEditProducts: true, canDeleteProducts: true,
        canUsePOS: true, canViewInventory: true, canModifyInventory: true, canImportInventory: true,
        canViewReports: true, canViewSuppliers: true, canViewExpenses: true, canViewClients: true,
        canViewSettings: true, canEditSettings: false, canManageUsers: false, canViewSalesHistory: true,
      }
    case 'seller':
      return {
        canViewDashboard: false, canViewProducts: true, canCreateEditProducts: false, canDeleteProducts: false,
        canUsePOS: true, canViewInventory: false, canModifyInventory: false, canImportInventory: false,
        canViewReports: false, canViewSuppliers: false, canViewExpenses: false, canViewClients: true,
        canViewSettings: false, canEditSettings: false, canManageUsers: false, canViewSalesHistory: false,
      }
    default:
      return {
        canViewDashboard: false, canViewProducts: false, canCreateEditProducts: false, canDeleteProducts: false,
        canUsePOS: false, canViewInventory: false, canModifyInventory: false, canImportInventory: false,
        canViewReports: false, canViewSuppliers: false, canViewExpenses: false, canViewClients: false,
        canViewSettings: false, canEditSettings: false, canManageUsers: false, canViewSalesHistory: false,
      }
  }
}

export const roleLabels: Record<UserRole, string> = {
  owner: '👑 Propietario',
  manager: '🏢 Gerente',
  seller: '🛒 Vendedor',
  none: '❌ Sin acceso',
}

export const roleDescriptions: Record<UserRole, string> = {
  owner: 'Acceso total: todo',
  manager: 'Puede gestionar productos, inventario y ventas',
  seller: 'Solo puede vender (punto de venta)',
  none: 'Sin permisos',
}
