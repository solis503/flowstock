'use client'
import { useState, useEffect } from 'react'
import { createClient } from '@/lib/supabase-client'
import { getPermissions, type UserRole } from '@/lib/permissions'
import * as XLSX from 'xlsx'

export default function ProductsPage() {
  const [products, setProducts] = useState<any[]>([])
  const [categories, setCategories] = useState<any[]>([])
  const [biz, setBiz] = useState<any>(null)
  const [role, setRole] = useState<UserRole>('none')
  const [loading, setLoading] = useState(true)
  const [showForm, setShowForm] = useState(false)
  const [editing, setEditing] = useState<any>(null)
  const [form, setForm] = useState({name:'',price:'',cost:'',stock:'',min_stock:'5',category_id:'',unit:'piezas',product_type:'simple',barcode:'',is_sellable:true})
  const [recipeItems, setRecipeItems] = useState<{product_id:string,quantity:string,ingredient_name:string}[]>([])
  const [showImport, setShowImport] = useState(false)
  const [importData, setImportData] = useState<any[]>([])
  const [importHeaders, setImportHeaders] = useState<string[]>([])
  const [columnMapping, setColumnMapping] = useState<Record<string,string>>({})
  const [importStep, setImportStep] = useState<'upload'|'map'|'preview'>('upload')
  const supabase = createClient()

  useEffect(() => { loadData() }, [])

  const loadData = async () => {
    setLoading(true)
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) return
    let b: any = null, r: UserRole = 'none'
    const { data: ob } = await supabase.from('businesses').select('*').eq('owner_id', user.id).single()
    if (ob) { b = ob; r = 'owner' }
    else { const { data: pr } = await supabase.from('profiles').select('*, businesses(*)').eq('user_id', user.id).eq('active', true).single(); if (pr) { b = pr.businesses; r = pr.role as UserRole } }
    if (!b) { setLoading(false); return }
    setBiz(b); setRole(r)
    const [prods, cats] = await Promise.all([
      supabase.from('products').select('*').eq('business_id', b.id).order('name'),
      supabase.from('categories').select('*').eq('business_id', b.id).order('name'),
    ])
    setProducts(prods.data || []); setCategories(cats.data || [])
    setLoading(false)
  }

  const perms = getPermissions(role)
  const curr = biz?.currency_symbol || '$'

  const resetForm = () => {
    setForm({name:'',price:'',cost:'',stock:'',min_stock:'5',category_id:'',unit:'piezas',product_type:'simple',barcode:'',is_sellable:true})
    setRecipeItems([]); setEditing(null); setShowForm(false)
  }

  const openCreate = (type: 'simple'|'receta') => { resetForm(); setForm(f => ({...f, product_type: type})); setShowForm(true) }

  const openEdit = async (product: any) => {
    setEditing(product)
    setForm({
      name: product.name, price: String(product.price), cost: String(product.cost||''), stock: String(product.stock),
      min_stock: String(product.min_stock), category_id: product.category_id||'', unit: product.unit,
      product_type: product.product_type, barcode: product.barcode||'', is_sellable: product.is_sellable,
    })
    if (product.product_type === 'receta') {
      const { data: ri } = await supabase.from('recipe_items').select('*, products(name)').eq('product_id', product.id)
      setRecipeItems((ri||[]).map((r:any) => ({product_id: r.ingredient_id, quantity: String(r.quantity), ingredient_name: r.products?.name||''})))
    } else { setRecipeItems([]) }
    setShowForm(true)
  }

  const handleSave = async () => {
    if (!form.name || !biz) return
    const data: any = {
      name: form.name, price: parseFloat(form.price)||0, cost: parseFloat(form.cost)||0,
      stock: parseFloat(form.stock)||0, min_stock: parseFloat(form.min_stock)||5,
      category_id: form.category_id||null, unit: form.unit, product_type: form.product_type,
      barcode: form.barcode||null, is_sellable: form.is_sellable, business_id: biz.id,
    }
    let productId: string
    if (editing) {
      await supabase.from('products').update(data).eq('id', editing.id)
      productId = editing.id
      if (editing.product_type === 'receta') await supabase.from('recipe_items').delete().eq('product_id', editing.id)
    } else {
      const { data: newP } = await supabase.from('products').insert(data).select().single()
      productId = newP?.id
    }
    if (form.product_type === 'receta' && productId) {
      for (const ri of recipeItems) {
        if (ri.product_id && parseFloat(ri.quantity) > 0) {
          await supabase.from('recipe_items').insert({ product_id: productId, ingredient_id: ri.product_id, quantity: parseFloat(ri.quantity) })
        }
      }
    }
    resetForm(); loadData()
  }

  const handleDelete = async (id: string) => { if(!confirm('¿Eliminar?'))return; await supabase.from('products').delete().eq('id',id); loadData() }

  const addRecipeIngredient = async (productId: string) => {
    const p = products.find(x => x.id === productId)
    if (p) setRecipeItems([...recipeItems, {product_id: productId, quantity: '1', ingredient_name: p.name}])
  }

  // IMPORT
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]; if (!file) return
    const reader = new FileReader()
    reader.onload = (evt) => {
      const wb = XLSX.read(evt.target?.result, {type:'binary'})
      const sheet = wb.Sheets[wb.SheetNames[0]]
      const data = XLSX.utils.sheet_to_json(sheet) as any[]
      if (data.length) { setImportHeaders(Object.keys(data[0])); setImportData(data); setImportStep('map') }
    }
    reader.readAsBinaryString(file)
  }

  const handleImport = async () => {
    if (!biz || !importData.length) return
    let count = 0
    for (const row of importData) {
      const nameKey = Object.entries(columnMapping).find(([,v])=>v==='name')?.[0]
      if (!nameKey) continue
      const name = String(row[nameKey]||'').trim(); if (!name) continue
      const priceKey = Object.entries(columnMapping).find(([,v])=>v==='price')?.[0]
      const stockKey = Object.entries(columnMapping).find(([,v])=>v==='stock')?.[0]
      const barcodeKey = Object.entries(columnMapping).find(([,v])=>v==='barcode')?.[0]
      await supabase.from('products').insert({
        name, price: parseFloat(row[priceKey||''])||0, stock: parseFloat(row[stockKey||''])||0,
        min_stock: 5, unit: 'piezas', product_type: 'simple', is_sellable: true,
        barcode: barcodeKey ? String(row[barcodeKey]||'') : null, business_id: biz.id,
      })
      count++
    }
    setShowImport(false); setImportData([]); setImportHeaders([]); setColumnMapping({}); setImportStep('upload')
    loadData(); alert(`✅ ${count} productos importados`)
  }

  if (loading) return <div className="flex items-center justify-center h-64"><div className="animate-spin text-4xl">⏳</div></div>

  const grouped = products.reduce((acc: any, p) => { const cat = p.category_id || 'sin-cat'; if(!acc[cat]) acc[cat]=[]; acc[cat].push(p); return acc }, {})

  return (
    <div>
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-6 gap-3">
        <h1 className="text-2xl font-bold text-gray-900">📦 Productos</h1>
        <div className="flex gap-2 flex-wrap">
          {perms.canImportInventory && <button onClick={()=>{setShowImport(true);setImportStep('upload')}} className="bg-purple-600 hover:bg-purple-700 text-white px-3 py-2 rounded-xl font-semibold text-sm">📥 Importar Excel</button>}
          {perms.canCreateEditProducts && <>
            <button onClick={()=>openCreate('simple')} className="bg-primary-600 hover:bg-primary-700 text-white px-3 py-2 rounded-xl font-semibold text-sm">+ Producto Simple</button>
            <button onClick={()=>openCreate('receta')} className="bg-orange-600 hover:bg-orange-700 text-white px-3 py-2 rounded-xl font-semibold text-sm">🍽️ Receta</button>
          </>}
        </div>
      </div>

      {Object.entries(grouped).map(([catId, prods]: any) => (
        <div key={catId} className="mb-6">
          <h2 className="text-sm font-semibold text-gray-500 mb-2">{catId === 'sin-cat' ? 'Sin Categoría' : categories.find(c=>c.id===catId)?.name || catId}</h2>
          <div className="bg-white rounded-2xl shadow-sm border overflow-hidden">
            <div className="overflow-x-auto"><table className="w-full">
              <thead className="bg-gray-50 border-b"><tr>
                <th className="text-left px-4 py-2 text-xs font-semibold text-gray-500">Producto</th>
                <th className="text-left px-4 py-2 text-xs font-semibold text-gray-500">Precio</th>
                <th className="text-left px-4 py-2 text-xs font-semibold text-gray-500">Stock</th>
                <th className="text-left px-4 py-2 text-xs font-semibold text-gray-500">Tipo</th>
                <th className="text-left px-4 py-2 text-xs font-semibold text-gray-500">Código</th>
                {perms.canCreateEditProducts && <th className="text-left px-4 py-2 text-xs font-semibold text-gray-500"></th>}
              </tr></thead>
              <tbody className="divide-y">{(prods as any[]).map(p => (
                <tr key={p.id} className="hover:bg-gray-50 cursor-pointer" onClick={()=>openEdit(p)}>
                  <td className="px-4 py-3"><span className="font-medium text-sm">{p.name}</span>
                    {p.product_type==='receta' && <span className="ml-2 text-xs bg-orange-100 text-orange-700 px-1.5 py-0.5 rounded-full">🍽️</span>}
                    {p.product_type==='insumo' && <span className="ml-2 text-xs bg-gray-100 text-gray-500 px-1.5 py-0.5 rounded-full">Insumo</span>}
                  </td>
                  <td className="px-4 py-3 text-sm">{p.price>0?`${curr}${Number(p.price).toFixed(2)}`:'-'}</td>
                  <td className="px-4 py-3"><span className={`px-2 py-0.5 rounded-full text-xs font-bold ${Number(p.stock)<=0?'bg-red-100 text-red-700':Number(p.stock)<=p.min_stock?'bg-amber-100 text-amber-700':'bg-green-100 text-green-700'}`}>{Number(p.stock)}</span></td>
                  <td className="px-4 py-3 text-xs text-gray-500">{p.product_type==='receta'?'Compuesto':p.product_type==='insumo'?'Insumo':'Simple'}</td>
                  <td className="px-4 py-3 text-xs text-gray-400 font-mono">{p.barcode||'-'}</td>
                  {perms.canCreateEditProducts && <td className="px-4 py-3" onClick={e=>e.stopPropagation()}>
                    <div className="flex gap-2"><button onClick={()=>openEdit(p)} className="text-primary-600 text-xs font-medium hover:underline">Editar</button>{perms.canDeleteProducts && <button onClick={()=>handleDelete(p.id)} className="text-red-600 text-xs font-medium hover:underline">Eliminar</button>}</div>
                  </td>}
                </tr>
              ))}</tbody>
            </table></div>
          </div>
        </div>
      ))}

      {/* FORM MODAL */}
      {showForm && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto p-6">
            <div className="flex justify-between mb-4"><h2 className="text-xl font-bold">{editing?'✏️ Editar':form.product_type==='receta'?'🍽️ Nueva Receta':'+ Nuevo Producto'}</h2><button onClick={resetForm} className="text-gray-400 text-2xl">✕</button></div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div><label className="text-sm font-medium mb-1 block">Nombre *</label><input value={form.name} onChange={e=>setForm({...form,name:e.target.value})} className="w-full px-3 py-2 rounded-lg border outline-none" placeholder="Nombre" /></div>
              <div><label className="text-sm font-medium mb-1 block">Precio Venta</label><input type="number" step="0.01" value={form.price} onChange={e=>setForm({...form,price:e.target.value})} className="w-full px-3 py-2 rounded-lg border outline-none" /></div>
              <div><label className="text-sm font-medium mb-1 block">Costo</label><input type="number" step="0.01" value={form.cost} onChange={e=>setForm({...form,cost:e.target.value})} className="w-full px-3 py-2 rounded-lg border outline-none" /></div>
              <div><label className="text-sm font-medium mb-1 block">Stock Actual</label><input type="number" step="0.01" value={form.stock} onChange={e=>setForm({...form,stock:e.target.value})} className="w-full px-3 py-2 rounded-lg border outline-none" /></div>
              <div><label className="text-sm font-medium mb-1 block">Stock Mínimo</label><input type="number" step="0.01" value={form.min_stock} onChange={e=>setForm({...form,min_stock:e.target.value})} className="w-full px-3 py-2 rounded-lg border outline-none" /></div>
              <div><label className="text-sm font-medium mb-1 block">Unidad</label><select value={form.unit} onChange={e=>setForm({...form,unit:e.target.value})} className="w-full px-3 py-2 rounded-lg border">{['piezas','kg','litros','cajas'].map(u=><option key={u}>{u}</option>)}</select></div>
              <div><label className="text-sm font-medium mb-1 block">Categoría</label><select value={form.category_id} onChange={e=>setForm({...form,category_id:e.target.value})} className="w-full px-3 py-2 rounded-lg border"><option value="">Sin categoría</option>{categories.map(c=><option key={c.id} value={c.id}>{c.name}</option>)}</select></div>
              <div><label className="text-sm font-medium mb-1 block">Código de Barras</label><input value={form.barcode} onChange={e=>setForm({...form,barcode:e.target.value})} className="w-full px-3 py-2 rounded-lg border outline-none font-mono" placeholder="7501234567890" /></div>
              {form.product_type!=='receta' && <div className="flex items-center gap-2 mt-6"><input type="checkbox" checked={form.is_sellable} onChange={e=>setForm({...form,is_sellable:e.target.checked})} className="rounded" id="sellable" /><label htmlFor="sellable" className="text-sm">Se puede vender</label></div>}
            </div>
            {/* Recipe builder */}
            {form.product_type==='receta' && (
              <div className="mt-4 border-t pt-4">
                <h3 className="font-semibold mb-3">🧩 Ingredientes de la Receta</h3>
                {recipeItems.map((ri,i) => (
                  <div key={i} className="flex items-center gap-2 bg-gray-50 rounded-lg p-2 mb-2">
                    <span className="flex-1 text-sm">{ri.ingredient_name}</span>
                    <input type="number" step="0.01" value={ri.quantity} onChange={e=>{const n=[...recipeItems];n[i].quantity=e.target.value;setRecipeItems(n)}} className="w-20 px-2 py-1 border rounded text-sm text-center" />
                    <button onClick={()=>setRecipeItems(recipeItems.filter((_,j)=>j!==i))} className="text-red-400">✕</button>
                  </div>
                ))}
                <div className="flex gap-2">
                  <select onChange={e=>{if(e.target.value){addRecipeIngredient(e.target.value);e.target.value=''}}} className="flex-1 px-2 py-1.5 border rounded text-sm">
                    <option value="">Seleccionar ingrediente...</option>
                    {products.filter(p=>p.product_type!=='receta').map(p=><option key={p.id} value={p.id}>{p.name} ({p.stock} disponibles)</option>)}
                  </select>
                </div>
              </div>
            )}
            <div className="flex gap-3 mt-6">
              <button onClick={handleSave} className="px-6 py-2 bg-primary-600 hover:bg-primary-700 text-white rounded-lg font-semibold">{editing?'💾 Guardar':'✅ Crear'}</button>
              <button onClick={resetForm} className="px-6 py-2 bg-gray-100 hover:bg-gray-200 rounded-lg font-semibold">Cancelar</button>
            </div>
          </div>
        </div>
      )}

      {/* IMPORT MODAL */}
      {showImport && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto p-6">
            <div className="flex justify-between mb-4"><h2 className="text-xl font-bold">📥 Importar Excel</h2><button onClick={()=>{setShowImport(false);setImportStep('upload')}} className="text-gray-400 text-2xl">✕</button></div>
            {importStep==='upload' && (
              <div className="text-center py-8 border-2 border-dashed rounded-2xl">
                <p className="text-4xl mb-4">📄</p>
                <p className="text-gray-600 mb-2">Selecciona tu archivo Excel o CSV</p>
                <label className="inline-block px-6 py-3 bg-purple-600 hover:bg-purple-700 text-white rounded-xl font-semibold cursor-pointer">
                  Elegir Archivo<input type="file" accept=".xlsx,.xls,.csv" onChange={handleFileUpload} className="hidden" />
                </label>
                <p className="text-xs text-gray-400 mt-3">Columnas sugeridas: Nombre, Precio, Stock, Código de Barras</p>
              </div>
            )}
            {importStep==='map' && (
              <div>
                <p className="text-sm text-gray-600 mb-4">{importData.length} filas encontradas. Asigna las columnas:</p>
                <div className="space-y-2 mb-4">
                  {[{f:'name',l:'📝 Nombre *'},{f:'price',l:'💰 Precio'},{f:'stock',l:'📦 Stock'},{f:'barcode',l:'📱 Código'}].map(({f,l}) => (
                    <div key={f} className="flex items-center gap-4">
                      <label className="w-28 text-sm font-medium">{l}</label>
                      <select value={Object.entries(columnMapping).find(([,v])=>v===f)?.[0]||''} onChange={e=>{const m={...columnMapping};Object.keys(m).forEach(k=>{if(m[k]===f)delete m[k]});if(e.target.value)m[e.target.value]=f;setColumnMapping(m)}} className="flex-1 px-3 py-2 rounded-lg border text-sm">
                        <option value="">— No usar —</option>
                        {importHeaders.map(h=><option key={h} value={h}>{h}</option>)}
                      </select>
                    </div>
                  ))}
                </div>
                <div className="flex gap-3">
                  <button onClick={()=>setImportStep('preview')} disabled={!Object.values(columnMapping).includes('name')} className="px-6 py-2 bg-purple-600 text-white rounded-lg font-semibold disabled:opacity-50">Siguiente →</button>
                  <button onClick={()=>setImportStep('upload')} className="px-6 py-2 bg-gray-100 rounded-lg font-semibold">← Volver</button>
                </div>
              </div>
            )}
            {importStep==='preview' && (
              <div>
                <p className="text-sm text-gray-600 mb-4">Se importarán {importData.length} productos:</p>
                <div className="overflow-x-auto max-h-48 overflow-y-auto border rounded-xl mb-4">
                  <table className="w-full text-sm"><thead className="bg-gray-50 sticky top-0"><tr><th className="px-3 py-2 text-left text-xs">#</th><th className="px-3 py-2 text-left text-xs">Datos</th></tr></thead>
                    <tbody className="divide-y">{importData.slice(0,10).map((row,i)=><tr key={i}><td className="px-3 py-1 text-gray-400">{i+1}</td><td className="px-3 py-1 font-mono text-xs">{JSON.stringify(row).slice(0,100)}</td></tr>)}</tbody>
                  </table>
                </div>
                <div className="flex gap-3">
                  <button onClick={handleImport} className="px-6 py-2 bg-green-600 text-white rounded-lg font-semibold">✅ Importar</button>
                  <button onClick={()=>setImportStep('map')} className="px-6 py-2 bg-gray-100 rounded-lg font-semibold">← Volver</button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  )
}
