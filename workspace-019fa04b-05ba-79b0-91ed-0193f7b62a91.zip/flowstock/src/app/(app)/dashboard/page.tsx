import { createServerSupabase } from '@/lib/supabase-server'
import { redirect } from 'next/navigation'

export const dynamic = 'force-dynamic'

export default async function DashboardPage() {
  const supabase = createServerSupabase()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) redirect('/login')

  let biz: any = null
  const { data: ob } = await supabase.from('businesses').select('*').eq('owner_id', user.id).single()
  if (ob) biz = ob
  else { const { data: pr } = await supabase.from('profiles').select('*, businesses(*)').eq('user_id', user.id).eq('active', true).single(); if (pr) biz = pr.businesses }
  if (!biz) redirect('/settings')

  const today = new Date().toISOString().split('T')[0]
  const curr = biz.currency_symbol || '$'

  const [salesRes, lowStockRes, expRes] = await Promise.all([
    supabase.from('sales').select('total, payment_method, created_at').eq('business_id', biz.id).gte('created_at', today),
    supabase.from('products').select('name, stock, min_stock, unit, category_id, product_type').eq('business_id', biz.id).lte('stock', 5).neq('product_type', 'insumo').order('stock'),
    supabase.from('expenses').select('amount').eq('business_id', biz.id).gte('created_at', today),
  ])

  const todaySales = salesRes.data || []
  const todayTotal = todaySales.reduce((s: number, v: any) => s + Number(v.total), 0)
  const lowStock = lowStockRes.data || []
  const totalExp = (expRes.data || []).reduce((s: number, v: any) => s + Number(v.amount), 0)

  const { data: recentSales } = await supabase.from('sales').select('*').eq('business_id', biz.id).order('created_at', { ascending: false }).limit(5)

  return (
    <div>
      <h1 className="text-2xl font-bold text-gray-900 mb-6">📊 Dashboard</h1>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-6">
        <div className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100">
          <p className="text-xs text-gray-500 mb-1">Ventas de Hoy</p>
          <p className="text-2xl font-bold text-primary-600">{curr}{todayTotal.toFixed(2)}</p>
          <p className="text-xs text-gray-400 mt-1">{todaySales.length} transacciones</p>
        </div>
        <div className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100">
          <p className="text-xs text-gray-500 mb-1">Gastos de Hoy</p>
          <p className="text-2xl font-bold text-red-500">{curr}{totalExp.toFixed(2)}</p>
        </div>
        <div className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100">
          <p className="text-xs text-gray-500 mb-1">Ganancia</p>
          <p className={`text-2xl font-bold ${todayTotal-totalExp>=0?'text-green-600':'text-red-600'}`}>{curr}{(todayTotal-totalExp).toFixed(2)}</p>
        </div>
        <div className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100">
          <p className="text-xs text-gray-500 mb-1">Alertas Stock</p>
          <p className="text-2xl font-bold text-amber-600">{lowStock.length}</p>
          <p className="text-xs text-gray-400 mt-1">productos bajo mínimo</p>
        </div>
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100">
          <div className="p-4 border-b"><h2 className="font-semibold">⚠️ Stock Bajo</h2></div>
          <div className="p-4 space-y-2">
            {lowStock.length > 0 ? lowStock.slice(0,8).map((p:any) => (
              <div key={p.id} className="flex justify-between items-center">
                <div><p className="text-sm font-medium">{p.name}</p></div>
                <span className={`px-2 py-0.5 rounded-full text-xs font-bold ${Number(p.stock)<=0?'bg-red-100 text-red-700':'bg-amber-100 text-amber-700'}`}>{Number(p.stock)} {p.unit}</span>
              </div>
            )) : <p className="text-gray-400 text-center text-sm py-4">Todo bien ✅</p>}
          </div>
        </div>
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100">
          <div className="p-4 border-b"><h2 className="font-semibold">🧾 Últimas Ventas</h2></div>
          <div className="p-4 space-y-2">
            {recentSales && recentSales.length > 0 ? recentSales.map((s:any) => (
              <div key={s.id} className="flex justify-between items-center py-1 border-b border-gray-50 last:border-0">
                <div><p className="font-medium text-sm">{curr}{Number(s.total).toFixed(2)}</p><p className="text-xs text-gray-400">{new Date(s.created_at).toLocaleDateString('es',{day:'numeric',month:'short',hour:'2-digit',minute:'2-digit'})}</p></div>
                <span className={`px-2 py-0.5 rounded-full text-xs font-semibold ${s.payment_method==='efectivo'?'bg-green-100 text-green-700':s.payment_method==='tarjeta'?'bg-blue-100 text-blue-700':'bg-purple-100 text-purple-700'}`}>{s.payment_method}</span>
              </div>
            )) : <p className="text-gray-400 text-center text-sm py-4">No hay ventas aún</p>}
          </div>
        </div>
      </div>
    </div>
  )
}
