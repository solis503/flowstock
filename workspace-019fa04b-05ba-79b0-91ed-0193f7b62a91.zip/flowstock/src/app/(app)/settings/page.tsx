'use client'
import { useState, useEffect } from 'react'
import { createClient } from '@/lib/supabase-client'
import { getPermissions, type UserRole } from '@/lib/permissions'
import { getAllProfiles, inviteUser, toggleUserActive, updateUserRole, removeUser } from '@/lib/user-management'
import { roleLabels, roleDescriptions } from '@/lib/permissions'

export default function SettingsPage() {
  const [biz, setBiz] = useState<any>(null)
  const [role, setRole] = useState<UserRole>('none')
  const [name, setName] = useState('')
  const [currency, setCurrency] = useState('$')
  const [tax, setTax] = useState('13')
  const [loyaltyRate, setLoyaltyRate] = useState('10')
  const [saved, setSaved] = useState(false)
  const [loading, setLoading] = useState(true)
  const [tab, setTab] = useState<'general'|'users'|'branches'|'loyalty'>('general')
  const [profiles, setProfiles] = useState<any[]>([])
  const [branches, setBranches] = useState<any[]>([])
  const [showInvite, setShowInvite] = useState(false)
  const [inviteForm, setInviteForm] = useState({email:'',name:'',role:'seller' as UserRole})
  const supabase = createClient()

  useEffect(() => { loadData() }, [])

  const loadData = async () => {
    setLoading(true)
    const { data: { user } } = await supabase.auth.getUser(); if (!user) return
    let b: any = null, r: UserRole = 'none'
    const { data: ob } = await supabase.from('businesses').select('*').eq('owner_id', user.id).single()
    if (ob) { b = ob; r = 'owner' }
    else { const { data: pr } = await supabase.from('profiles').select('*, businesses(*)').eq('user_id', user.id).eq('active', true).single(); if (pr) { b = pr.businesses; r = pr.role as UserRole } }
    if (!b) { setLoading(false); return }
    setBiz(b); setRole(r)
    setName(b.name); setCurrency(b.currency_symbol); setTax(String(b.tax_percentage)); setLoyaltyRate(String(b.loyalty_points_rate||10))
    if (r === 'owner') {
      setProfiles(await getAllProfiles(b.id))
      const { data: br } = await supabase.from('branches').select('*').eq('business_id', b.id)
      setBranches(br || [])
    }
    setLoading(false)
  }

  const perms = getPermissions(role)

  const handleSave = async () => {
    if (!biz || !perms.canEditSettings) return
    await supabase.from('businesses').update({ name, currency_symbol: currency, tax_percentage: parseFloat(tax)||0, loyalty_points_rate: parseFloat(loyaltyRate)||10 }).eq('id', biz.id)
    setSaved(true); setTimeout(()=>setSaved(false),3000); loadData()
  }

  const handleInvite = async () => {
    if (!biz || !inviteForm.email) return
    const res = await inviteUser(biz.id, inviteForm.email, inviteForm.role, inviteForm.name)
    if (res.error) alert(res.error); else { setProfiles(await getAllProfiles(biz.id)); setShowInvite(false); setInviteForm({email:'',name:'',role:'seller'}) }
  }

  const handleAddBranch = async () => {
    if (!biz) return
    const name = prompt('Nombre de la nueva sucursal:')
    if (!name) return
    await supabase.from('branches').insert({ business_id: biz.id, name })
    loadData()
  }

  if (loading) return <div className="flex items-center justify-center h-64"><div className="animate-spin text-4xl">⏳</div></div>
  if (!perms.canViewSettings) return <div className="flex items-center justify-center h-64"><div className="text-center"><p className="text-4xl mb-4">🔒</p><p className="text-gray-500 text-lg">Sin acceso</p></div></div>

  return (
    <div>
      <h1 className="text-2xl font-bold text-gray-900 mb-6">⚙️ Configuración</h1>
      <div className="flex gap-2 mb-6 flex-wrap">
        {[['general','🏢 General'],['users','👥 Usuarios'],['branches','📍 Sucursales'],['loyalty','⭐ Lealtad']].map(([v,l]) => (
          <button key={v} onClick={()=>setTab(v as any)} className={`px-4 py-2 rounded-xl text-sm font-semibold transition ${tab===v?'bg-primary-100 text-primary-700':'bg-white border border-gray-200 hover:bg-gray-50'}`}>{l}</button>
        ))}
      </div>

      {tab==='general' && (
        <div className="bg-white rounded-2xl shadow-sm border p-6 space-y-6">
          <div><label className="text-sm font-medium mb-1 block">Nombre del Negocio</label><input value={name} onChange={e=>setName(e.target.value)} disabled={!perms.canEditSettings} className="w-full px-4 py-3 rounded-xl border outline-none disabled:bg-gray-50" /></div>
          <div><label className="text-sm font-medium mb-1 block">Moneda</label>
            <div className="flex gap-2 flex-wrap">{['$','€','RD$','Q','L','S/','Bs','₡','£','¥'].map(s => (
              <button key={s} onClick={()=>perms.canEditSettings&&setCurrency(s)} disabled={!perms.canEditSettings} className={`px-4 py-2 rounded-xl border-2 font-semibold ${currency===s?'border-primary-600 bg-primary-50 text-primary-700':'border-gray-200 text-gray-600'} disabled:opacity-50`}>{s}</button>
            ))}</div>
          </div>
          <div><label className="text-sm font-medium mb-1 block">IVA (%)</label><div className="flex items-center gap-2"><input type="number" step="0.01" value={tax} onChange={e=>setTax(e.target.value)} disabled={!perms.canEditSettings} className="w-32 px-4 py-3 rounded-xl border outline-none" /><span className="font-semibold">%</span></div></div>
          {perms.canEditSettings && <div className="flex items-center gap-4"><button onClick={handleSave} className="px-8 py-3 bg-primary-600 hover:bg-primary-700 text-white font-bold rounded-xl">💾 Guardar</button>{saved && <span className="text-green-600 font-semibold">✓ Guardado</span>}</div>}
        </div>
      )}

      {tab==='users' && perms.canManageUsers && (
        <div>
          <div className="bg-white rounded-2xl shadow-sm border p-6 mb-6">
            <h2 className="font-semibold mb-4">📋 Permisos por Rol</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-4"><h3 className="font-bold text-yellow-800">👑 Propietario</h3><p className="text-sm text-yellow-700">Acceso total: todo</p></div>
              <div className="bg-blue-50 border border-blue-200 rounded-xl p-4"><h3 className="font-bold text-blue-800">🏢 Gerente</h3><p className="text-sm text-blue-700">Productos, inventario, ventas, reportes</p></div>
              <div className="bg-green-50 border border-green-200 rounded-xl p-4"><h3 className="font-bold text-green-800">🛒 Vendedor</h3><p className="text-sm text-green-700">Solo punto de venta y clientes</p></div>
            </div>
          </div>
          <div className="bg-white rounded-2xl shadow-sm border overflow-hidden">
            <div className="p-4 border-b flex items-center justify-between"><h2 className="font-semibold">👥 Usuarios</h2><button onClick={()=>setShowInvite(true)} className="bg-primary-600 text-white px-4 py-2 rounded-xl font-semibold text-sm">+ Agregar</button></div>
            <div className="p-4 border-b bg-yellow-50/50 flex items-center gap-4"><div className="w-10 h-10 bg-yellow-200 rounded-full flex items-center justify-center">👑</div><div className="flex-1"><p className="font-semibold">Tú (Propietario)</p></div><span className="px-3 py-1 bg-yellow-100 text-yellow-700 rounded-full text-sm font-semibold">Propietario</span></div>
            <div className="divide-y">{profiles.map((p:any) => (
              <div key={p.id} className="p-4 flex items-center gap-4">
                <div className="w-10 h-10 bg-gray-200 rounded-full flex items-center justify-center text-sm font-medium">{(p.full_name||p.email||'?').charAt(0).toUpperCase()}</div>
                <div className="flex-1 min-w-0"><p className="font-medium">{p.full_name||'Sin nombre'} {!p.active && <span className="text-xs bg-red-100 text-red-600 px-2 py-0.5 rounded-full">Inactivo</span>}</p><p className="text-sm text-gray-500 truncate">{p.email}</p></div>
                <select value={p.role} onChange={e=>updateUserRole(p.id,e.target.value as UserRole).then(()=>loadData())} className="px-3 py-1.5 rounded-lg border text-sm"><option value="manager">🏢 Gerente</option><option value="seller">🛒 Vendedor</option></select>
                <button onClick={()=>toggleUserActive(p.id,!p.active).then(()=>loadData())} className={`px-3 py-1.5 rounded-lg text-sm font-semibold ${p.active?'bg-green-100 text-green-700':'bg-red-100 text-red-700'}`}>{p.active?'Activo':'Inactivo'}</button>
                <button onClick={()=>{if(confirm('¿Eliminar?'))removeUser(p.id).then(()=>loadData())}} className="text-red-600 text-sm">🗑️</button>
              </div>
            ))}</div>
          </div>
          {showInvite && (
            <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
              <div className="bg-white rounded-2xl w-full max-w-md p-6">
                <h2 className="text-xl font-bold mb-4">+ Agregar Usuario</h2>
                <div className="space-y-3">
                  <input value={inviteForm.name} onChange={e=>setInviteForm({...inviteForm,name:e.target.value})} className="w-full px-4 py-3 rounded-xl border outline-none" placeholder="Nombre" />
                  <input value={inviteForm.email} onChange={e=>setInviteForm({...inviteForm,email:e.target.value})} className="w-full px-4 py-3 rounded-xl border outline-none" placeholder="Email *" />
                  <div className="grid grid-cols-2 gap-2">{(['manager','seller'] as UserRole[]).map(r => (
                    <button key={r} onClick={()=>setInviteForm({...inviteForm,role:r})} className={`p-3 rounded-xl border-2 text-left ${inviteForm.role===r?'border-primary-600 bg-primary-50':'border-gray-200'}`}><p className="font-semibold text-sm">{roleLabels[r]}</p><p className="text-xs text-gray-500">{roleDescriptions[r]}</p></button>
                  ))}</div>
                </div>
                <div className="flex gap-3 mt-6"><button onClick={handleInvite} className="flex-1 py-3 bg-primary-600 text-white font-bold rounded-xl">✅ Agregar</button><button onClick={()=>setShowInvite(false)} className="px-6 py-3 bg-gray-100 rounded-xl font-semibold">Cancelar</button></div>
              </div>
            </div>
          )}
        </div>
      )}

      {tab==='branches' && perms.canEditSettings && (
        <div className="bg-white rounded-2xl shadow-sm border p-6">
          <h2 className="font-semibold mb-4">📍 Gestión de Sucursales</h2>
          <div className="space-y-3 mb-4">{branches.map((b:any) => (
            <div key={b.id} className="flex items-center gap-3 p-3 border rounded-xl"><span className="text-lg">📍</span><div className="flex-1"><p className="font-medium">{b.name}</p>{b.address && <p className="text-xs text-gray-500">{b.address}</p>}</div><span className={`px-2 py-1 rounded text-xs font-semibold ${b.active?'bg-green-100 text-green-700':'bg-red-100 text-red-700'}`}>{b.active?'Activa':'Inactiva'}</span></div>
          ))}</div>
          <button onClick={handleAddBranch} className="px-4 py-2 bg-primary-600 text-white rounded-xl text-sm font-semibold">+ Nueva Sucursal</button>
        </div>
      )}

      {tab==='loyalty' && (
        <div className="bg-white rounded-2xl shadow-sm border p-6 space-y-4">
          <h2 className="font-semibold mb-2">⭐ Programa de Lealtad</h2>
          <div><label className="text-sm font-medium mb-1 block">Puntos por cada</label><div className="flex items-center gap-2"><input type="number" value={loyaltyRate} onChange={e=>setLoyaltyRate(e.target.value)} disabled={!perms.canEditSettings} className="w-32 px-4 py-3 rounded-xl border outline-none" /><span className="text-gray-500">de compra = 1 punto</span></div></div>
          <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-4">
            <p className="text-sm text-yellow-700">Los clientes acumulan puntos con cada compra. Puedes configurar descuentos canjeables en el futuro.</p>
          </div>
          {perms.canEditSettings && <button onClick={handleSave} className="px-6 py-3 bg-primary-600 text-white font-bold rounded-xl">💾 Guardar</button>}
        </div>
      )}
    </div>
  )
}
