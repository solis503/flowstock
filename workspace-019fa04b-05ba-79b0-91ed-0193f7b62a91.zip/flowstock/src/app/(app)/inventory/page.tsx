'use client'
import { useState, useEffect } from 'react'
import { createClient } from '@/lib/supabase-client'
import { getPermissions, type UserRole } from '@/lib/permissions'

export default function InventoryPage() {
  const [products, setProducts] = useState<any[]>([])
  const [movements, setMovements] = useState<any[]>([])
  const [suppliers, setSuppliers] = useState<any[]>([])
  const [biz, setBiz] = useState<any>(null)
  const [role, setRole] = useState<UserRole>('none')
  const [showMove, setShowMove] = useState<{type:'entrada'|'salida',product:any}|null>(null)
  const [showImport, setShowImport] = useState(false)
  const [showPO, setShowPO] = useState(false)
  const [filter, setFilter] = useState('all')
  const [loading, setLoading] = useState(true)
  const supabase = createClient()

  useEffect(() => { loadData() }, [])

  const loadData = async () => {
    setLoading(true)
    const { data: { user } } = await supabase.auth.getUser(); if (!user) return
    let b: any = null, r: UserRole = 'none'
    const { data: ob } = await supabase.from('businesses').select('*').eq('owner_id', user.id).single()
    if (ob) { b = ob; r = 'owner' }
    else { const { data: pr } = await supabase.from('profiles').select('*, businesses(*)').eq('user_id', user.id).eq('active', true).single(); if (pr) { b = pr.businesses; r = pr.role as UserRole } }
    if (!b) { setLoading(false); return }
    setBiz(b); setRole(r)
    const [p, m, s] = await Promise.all([
      supabase.from('products').select('*').eq('business_id', b.id).neq('product_type','receta').order('name'),
      supabase.from('inventory_movements').select('*, products(name)').eq('business_id', b.id).order('created_at',{ascending:false}).limit(50),
      supabase.from('suppliers').select('*').eq('business_id', b.id).eq('active', true).order('name'),
    ])
    setProducts(p.data||[]); setMovements(m.data||[]); setSuppliers(s.data||[])
    setLoading(false)
  }

  const perms = getPermissions(role)

  const confirmMove = async () => {
    if (!showMove || !biz) return
    const qtyEl = document.getElementById('mvQty') as HTMLInputElement
    const notesEl = document.getElementById('mvNotes') as HTMLInputElement
    const qty = parseFloat(qtyEl?.value)||0; if (qty<=0) return
    const notes = notesEl?.value||''
    const p = showMove.product
    const newStock = showMove.type==='entrada' ? Number(p.stock)+qty : Math.max(0, Number(p.stock)-qty)
    await supabase.from('products').update({stock:newStock}).eq('id',p.id)
    await supabase.from('inventory_movements').insert({business_id:biz.id,product_id:p.id,type:showMove.type,quantity:qty,notes:notes||`${showMove.type} manual`})
    setShowMove(null); loadData()
  }

  const filtered = products.filter(p => {
    if (filter==='low') return Number(p.stock)<=Number(p.min_stock)&&Number(p.stock)>0
    if (filter==='out') return Number(p.stock)<=0
    return true
  })

  if (loading) return <div className="flex items-center justify-center h-64"><div className="animate-spin text-4xl">⏳</div></div>

  return (
    <div>
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-6 gap-3">
        <h1 className="text-2xl font-bold text-gray-900">🏷️ Inventario</h1>
        {perms.canModifyInventory && (
          <div className="flex gap-2">
            <button onClick={()=>setShowPO(true)} className="bg-amber-600 hover:bg-amber-700 text-white px-3 py-2 rounded-xl font-semibold text-sm">📋 Orden Compra</button>
            <button onClick={()=>setShowImport(true)} className="bg-purple-600 hover:bg-purple-700 text-white px-3 py-2 rounded-xl font-semibold text-sm">📥 Excel</button>
          </div>
        )}
      </div>

      <div className="flex gap-2 mb-6">
        {[['all','Todos'],['low','⚠️ Bajo'],['out','🔴 Sin Stock']].map(([v,l]) => (
          <button key={v} onClick={()=>setFilter(v)} className={`px-4 py-2 rounded-xl text-sm font-semibold transition ${filter===v?'bg-primary-100 text-primary-700':'bg-white border border-gray-200 hover:bg-gray-50'}`}>{l}</button>
        ))}
      </div>

      <div className="bg-white rounded-2xl shadow-sm border overflow-hidden mb-8">
        <div className="overflow-x-auto"><table className="w-full">
          <thead className="bg-gray-50 border-b"><tr>
            <th className="text-left px-4 py-2 text-xs font-semibold text-gray-500">Producto</th>
            <th className="text-left px-4 py-2 text-xs font-semibold text-gray-500">Stock</th>
            <th className="text-left px-4 py-2 text-xs font-semibold text-gray-500">Mínimo</th>
            <th className="text-left px-4 py-2 text-xs font-semibold text-gray-500">Estado</th>
            {perms.canModifyInventory && <th className="text-left px-4 py-2 text-xs font-semibold text-gray-500">Acciones</th>}
          </tr></thead>
          <tbody className="divide-y">{filtered.map(p => (
            <tr key={p.id} className="hover:bg-gray-50">
              <td className="px-4 py-3 text-sm font-medium">{p.name}</td>
              <td className="px-4 py-3"><span className={`px-2 py-0.5 rounded-full text-xs font-bold ${Number(p.stock)<=0?'bg-red-100 text-red-700':Number(p.stock)<=p.min_stock?'bg-amber-100 text-amber-700':'bg-green-100 text-green-700'}`}>{Number(p.stock)} {p.unit}</span></td>
              <td className="px-4 py-3 text-sm text-gray-600">{p.min_stock}</td>
              <td className="px-4 py-3 text-sm">{Number(p.stock)<=0?'🔴 Agotado':Number(p.stock)<=p.min_stock?'⚠️ Bajo':'✅ OK'}</td>
              {perms.canModifyInventory && <td className="px-4 py-3"><div className="flex gap-1">
                <button onClick={()=>setShowMove({type:'entrada',product:p})} className="px-2 py-1 bg-green-100 text-green-700 rounded text-xs font-semibold">+ Entrada</button>
                <button onClick={()=>setShowMove({type:'salida',product:p})} className="px-2 py-1 bg-red-100 text-red-700 rounded text-xs font-semibold">- Salida</button>
              </div></td>}
            </tr>
          ))}</tbody>
        </table></div>
      </div>

      <div className="bg-white rounded-2xl shadow-sm border overflow-hidden">
        <div className="p-4 border-b"><h2 className="font-semibold">📋 Historial de Movimientos</h2></div>
        {movements.length===0 ? <div className="p-8 text-center text-gray-400">No hay movimientos</div> : (
          <div className="overflow-x-auto"><table className="w-full text-sm">
            <thead className="bg-gray-50 border-b"><tr><th className="text-left px-4 py-2 text-xs font-semibold text-gray-500">Fecha</th><th className="text-left px-4 py-2 text-xs font-semibold text-gray-500">Producto</th><th className="text-left px-4 py-2 text-xs font-semibold text-gray-500">Tipo</th><th className="text-left px-4 py-2 text-xs font-semibold text-gray-500">Cantidad</th><th className="text-left px-4 py-2 text-xs font-semibold text-gray-500">Notas</th></tr></thead>
            <tbody className="divide-y">{movements.map((m:any) => (
              <tr key={m.id} className="hover:bg-gray-50">
                <td className="px-4 py-2">{new Date(m.created_at).toLocaleDateString('es',{day:'numeric',month:'short',hour:'2-digit',minute:'2-digit'})}</td>
                <td className="px-4 py-2 font-medium">{m.products?.name||'-'}</td>
                <td className="px-4 py-2"><span className={`px-2 py-0.5 rounded-full text-xs font-semibold ${m.type==='entrada'?'bg-green-100 text-green-700':m.type==='venta'?'bg-blue-100 text-blue-700':'bg-red-100 text-red-700'}`}>{m.type}</span></td>
                <td className="px-4 py-2 font-semibold">{m.quantity}</td>
                <td className="px-4 py-2 text-gray-500">{m.notes}</td>
              </tr>
            ))}</tbody>
          </table></div>
        )}
      </div>

      {/* Movement Modal */}
      {showMove && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl w-full max-w-md p-6">
            <h2 className="text-xl font-bold mb-3">{showMove.type==='entrada'?'📥 Entrada':'📤 Salida'} de Stock</h2>
            <p className="text-gray-600 text-sm mb-3">Producto: <strong>{showMove.product.name}</strong> | Stock: <strong>{showMove.product.stock} {showMove.product.unit}</strong></p>
            <input id="mvQty" type="number" step="0.01" className="w-full px-4 py-3 rounded-xl border outline-none mb-3" placeholder="Cantidad" autoFocus />
            <input id="mvNotes" type="text" className="w-full px-4 py-3 rounded-xl border outline-none mb-3" placeholder="Notas (opcional)" />
            <div className="flex gap-3">
              <button onClick={confirmMove} className={`flex-1 py-3 font-bold rounded-xl text-white ${showMove.type==='entrada'?'bg-green-600':'bg-red-600'}`}>Confirmar</button>
              <button onClick={()=>setShowMove(null)} className="px-6 py-3 bg-gray-100 rounded-xl font-semibold">Cancelar</button>
            </div>
          </div>
        </div>
      )}

      {/* Purchase Order Modal */}
      {showPO && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl w-full max-w-lg p-6">
            <div className="flex justify-between mb-4"><h2 className="text-xl font-bold">📋 Orden de Compra</h2><button onClick={()=>setShowPO(false)} className="text-gray-400 text-2xl">✕</button></div>
            <div className="space-y-3">
              <select className="w-full px-4 py-3 rounded-xl border outline-none"><option value="">Seleccionar proveedor...</option>{suppliers.map(s=><option key={s.id}>{s.name}</option>)}</select>
              <div className="space-y-2">
                <p className="text-sm font-medium">Productos a pedir:</p>
                {products.filter(p=>p.product_type==='insumo').slice(0,6).map(p => (
                  <div key={p.id} className="flex items-center gap-2"><input type="checkbox" className="rounded" /><span className="flex-1 text-sm">{p.name}</span><input type="number" className="w-20 px-2 py-1 border rounded text-sm" placeholder="Cant." /></div>
                ))}
              </div>
              <textarea className="w-full px-4 py-3 rounded-xl border outline-none" placeholder="Notas adicionales..." rows={2}></textarea>
            </div>
            <div className="flex gap-3 mt-4">
              <button onClick={()=>{setShowPO(false);alert('📋 Orden de compra enviada al proveedor')}} className="flex-1 py-3 bg-amber-600 text-white font-bold rounded-xl">📤 Enviar Orden</button>
              <button onClick={()=>setShowPO(false)} className="px-6 py-3 bg-gray-100 rounded-xl font-semibold">Cancelar</button>
            </div>
          </div>
        </div>
      )}

      {/* Import Modal */}
      {showImport && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl w-full max-w-lg p-6">
            <div className="flex justify-between mb-4"><h2 className="text-xl font-bold">📥 Actualizar Stock desde Excel</h2><button onClick={()=>setShowImport(false)} className="text-gray-400 text-2xl">✕</button></div>
            <div className="text-center py-8 border-2 border-dashed rounded-2xl">
              <p className="text-4xl mb-3">📄</p>
              <p className="text-gray-600 mb-2">Sube un Excel con columnas: <strong>Nombre</strong> y <strong>Cantidad</strong></p>
              <label className="inline-block px-6 py-3 bg-purple-600 text-white rounded-xl font-semibold cursor-pointer">Elegir Archivo<input type="file" accept=".xlsx,.xls,.csv" className="hidden" /></label>
            </div>
            <button onClick={()=>setShowImport(false)} className="mt-4 w-full py-2 bg-gray-100 rounded-xl font-semibold">Cerrar</button>
          </div>
        </div>
      )}
    </div>
  )
}
