'use client'
import { useState, useEffect } from 'react'
import { createClient } from '@/lib/supabase-client'

export default function POSPage() {
  const [products, setProducts] = useState<any[]>([])
  const [clients, setClients] = useState<any[]>([])
  const [biz, setBiz] = useState<any>(null)
  const [cart, setCart] = useState<any[]>([])
  const [search, setSearch] = useState('')
  const [selectedClient, setSelectedClient] = useState('')
  const [showPay, setShowPay] = useState(false)
  const [showSaleOk, setShowSaleOk] = useState(false)
  const [showScanner, setShowScanner] = useState(false)
  const [payMethod, setPayMethod] = useState('efectivo')
  const [amountPaid, setAmountPaid] = useState('')
  const [saleResult, setSaleResult] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const supabase = createClient()

  useEffect(() => { loadData() }, [])

  const loadData = async () => {
    setLoading(true)
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) return
    let b: any = null
    const { data: ob } = await supabase.from('businesses').select('*').eq('owner_id', user.id).single()
    if (ob) b = ob
    else { const { data: pr } = await supabase.from('profiles').select('*, businesses(*)').eq('user_id', user.id).eq('active', true).single(); if (pr) b = pr.businesses }
    if (!b) { setLoading(false); return }
    setBiz(b)
    const [prods, clis] = await Promise.all([
      supabase.from('products').select('*').eq('business_id', b.id).eq('is_sellable', true).gt('stock', 0).order('name'),
      supabase.from('clients').select('*').eq('business_id', b.id).eq('active', true).order('name'),
    ])
    setProducts(prods.data || []); setClients(clis.data || [])
    setLoading(false)
  }

  const addToCart = (product: any) => {
    setCart(prev => {
      const ex = prev.find(i => i.id === product.id)
      if (ex) { if (ex.qty >= product.stock) return prev; return prev.map(i => i.id===product.id?{...i,qty:i.qty+1}:i) }
      return [...prev, { id:product.id, name:product.name, price:product.price, qty:1 }]
    })
  }

  const updQty = (id: string, d: number) => {
    setCart(prev => prev.map(i => i.id===id?{...i,qty:Math.max(0,i.qty+d)}:i).filter(i=>i.qty>0))
  }

  const subtotal = cart.reduce((s,i) => s + i.price*i.qty, 0)
  const tax = subtotal * ((biz?.tax_percentage||0)/100)
  const total = subtotal + tax
  const curr = biz?.currency_symbol || '$'

  const openPayment = () => { setAmountPaid(total.toFixed(2)); setShowPay(true) }

  const completeSale = async () => {
    if (!biz) return
    const { data: { user } } = await supabase.auth.getUser(); if (!user) return
    const paid = parseFloat(amountPaid) || total
    const change = payMethod === 'efectivo' ? Math.max(0, paid-total) : 0

    const { data: sale } = await supabase.from('sales').insert({
      business_id: biz.id, user_id: user.id,
      client_id: selectedClient || null,
      total, tax_amount: tax, payment_method: payMethod,
      amount_paid: paid, change_amount: change,
    }).select().single()
    if (!sale) return

    for (const item of cart) {
      await supabase.from('sale_items').insert({
        sale_id: sale.id, product_id: item.id, product_name: item.name,
        quantity: item.qty, unit_price: item.price, subtotal: item.price*item.qty,
      })
      const prod = products.find(p=>p.id===item.id)
      if (prod?.product_type === 'receta') {
        await supabase.rpc('decrement_recipe', { p_product_id: item.id, p_multiplier: item.qty })
      } else if (prod?.product_type !== 'insumo') {
        await supabase.rpc('decrement_stock', { p_product_id: item.id, p_quantity: item.qty })
      }
      await supabase.from('inventory_movements').insert({
        business_id: biz.id, product_id: item.id, type: 'venta', quantity: item.qty, notes: `Venta #${sale.id.slice(0,8)}`,
      })
    }

    // Puntos de lealtad
    if (selectedClient) {
      const points = Math.floor(total / (biz.loyalty_points_rate || 10))
      const { data: clientData } = await supabase.from('clients').select('loyalty_points, total_spent').eq('id', selectedClient).single()
      if (clientData) {
        await supabase.from('clients').update({
          loyalty_points: (clientData.loyalty_points||0) + points,
          total_spent: (Number(clientData.total_spent)||0) + total
        }).eq('id', selectedClient)
      }
    }

    setSaleResult({ total, change, method: payMethod, products: cart.map(i=>({name:i.name,qty:i.qty,price:i.price})) })
    setCart([]); setShowPay(false); setShowSaleOk(true); setSelectedClient('')
    loadData()
  }

  const printTicket = () => {
    if (!saleResult || !biz) return
    const items = saleResult.products.map((p:any) => `<tr><td class="py-0.5">${p.name} x${p.qty}</td><td class="text-right">${curr}${(p.price*p.qty).toFixed(2)}</td></tr>`).join('')
    const win = window.open('','_blank','width=350,height=600')
    if (!win) return
    win.document.write(`<html><head><title>Ticket</title><style>body{font-family:monospace;font-size:12px;padding:10px;max-width:300px;margin:0 auto}table{width:100%;border-collapse:collapse}.c{text-align:center}.line{border-top:1px dashed #000;margin:5px 0}</style></head><body>
      <div class="c"><strong>${biz.name}</strong><br>${new Date().toLocaleString('es')}<br>Ticket #${Date.now().toString().slice(-6)}</div>
      <div class="line"></div><table>${items}</table><div class="line"></div>
      <table><tr><td><strong>TOTAL</strong></td><td class="text-right"><strong>${curr}${saleResult.total.toFixed(2)}</strong></td></tr>
      <tr><td>Método:</td><td class="text-right">${saleResult.method}</td></tr>
      ${saleResult.method==='efectivo'?`<tr><td>Pagado:</td><td class="text-right">${curr}${(saleResult.total+saleResult.change).toFixed(2)}</td></tr><tr><td>Cambio:</td><td class="text-right">${curr}${saleResult.change.toFixed(2)}</td></tr>`:''}
      </table><div class="line"></div><div class="c">¡Gracias por su compra!</div></body></html>`)
    win.document.close(); win.print()
  }

  const scanBarcode = () => {
    const code = search.trim(); if (!code) return
    const p = products.find(x => x.barcode === code)
    if (p) { addToCart(p); setSearch('') }
  }

  const filtered = products.filter(p => p.name.toLowerCase().includes(search.toLowerCase()) || p.barcode?.includes(search))

  if (loading) return <div className="flex items-center justify-center h-64"><div className="animate-spin text-4xl">⏳</div></div>

  return (
    <div className="flex flex-col lg:flex-row gap-4" style={{minHeight:'calc(100vh - 6rem)'}}>
      <div className="flex-1 flex flex-col min-w-0">
        <div className="flex items-center justify-between mb-4">
          <h1 className="text-2xl font-bold text-gray-900">🛒 Punto de Venta</h1>
          <button onClick={()=>setShowScanner(true)} className="px-3 py-2 bg-gray-800 text-white rounded-xl text-sm font-semibold">📱 Escanear</button>
        </div>
        <div className="flex gap-2 mb-4">
          <input value={search} onChange={e=>setSearch(e.target.value)} onKeyDown={e=>{if(e.key==='Enter')scanBarcode()}}
            placeholder="🔍 Buscar o escanear código de barras..." className="flex-1 px-4 py-3 rounded-xl border border-gray-200 outline-none bg-white" />
          <button onClick={scanBarcode} className="px-4 py-3 bg-primary-600 text-white rounded-xl font-semibold text-sm">Buscar</button>
        </div>
        <div className="flex-1 overflow-y-auto">
          <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-3">
            {filtered.map(p => (
              <button key={p.id} onClick={()=>addToCart(p)} className="bg-white rounded-xl p-3 border border-gray-100 hover:border-primary-300 hover:shadow-md transition text-left">
                <p className="font-medium text-gray-900 text-sm truncate">{p.name}</p>
                {p.product_type==='receta' && <span className="text-xs bg-orange-100 text-orange-700 px-1.5 py-0.5 rounded-full">🍽️</span>}
                <p className="text-primary-600 font-bold mt-1">{curr}{Number(p.price).toFixed(2)}</p>
                <p className="text-xs text-gray-400">{p.stock} {p.unit}</p>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Cart */}
      <div className="lg:w-80 bg-white rounded-2xl shadow-sm border border-gray-100 flex flex-col">
        <div className="p-3 border-b flex justify-between items-center">
          <h2 className="font-semibold">🧾 Carrito</h2>
          {cart.length>0 && <button onClick={()=>setCart([])} className="text-xs text-red-500 hover:underline">Vaciar</button>}
        </div>
        {/* Client selector */}
        <div className="px-3 pt-2">
          <select value={selectedClient} onChange={e=>setSelectedClient(e.target.value)} className="w-full px-2 py-1.5 rounded-lg border border-gray-200 text-sm">
            <option value="">👤 Cliente general</option>
            {clients.map(c=><option key={c.id} value={c.id}>{c.name} (⭐{c.loyalty_points||0})</option>)}
          </select>
        </div>
        <div className="flex-1 overflow-y-auto p-3 space-y-2">
          {cart.length===0 ? <p className="text-center text-gray-400 py-8 text-sm">Agrega productos</p> :
            cart.map(item => (
              <div key={item.id} className="flex items-center gap-2 bg-gray-50 rounded-xl p-2">
                <div className="flex-1 min-w-0"><p className="font-medium text-sm truncate">{item.name}</p><p className="text-xs text-gray-500">{curr}{item.price.toFixed(2)}</p></div>
                <div className="flex items-center gap-1">
                  <button onClick={()=>updQty(item.id,-1)} className="w-6 h-6 rounded bg-white border text-xs">-</button>
                  <span className="w-6 text-center text-sm font-semibold">{item.qty}</span>
                  <button onClick={()=>updQty(item.id,1)} className="w-6 h-6 rounded bg-white border text-xs">+</button>
                </div>
              </div>
            ))
          }
        </div>
        <div className="p-3 border-t space-y-1">
          <div className="flex justify-between text-sm text-gray-600"><span>Subtotal</span><span>{curr}{subtotal.toFixed(2)}</span></div>
          {(biz?.tax_percentage||0)>0 && <div className="flex justify-between text-sm text-gray-600"><span>IVA ({biz?.tax_percentage}%)</span><span>{curr}{tax.toFixed(2)}</span></div>}
          <div className="flex justify-between text-lg font-bold pt-1 border-t"><span>Total</span><span>{curr}{total.toFixed(2)}</span></div>
          <button onClick={openPayment} disabled={!cart.length} className="w-full py-2.5 bg-primary-600 hover:bg-primary-700 text-white font-bold rounded-xl mt-2 disabled:opacity-50">Cobrar {curr}{total.toFixed(2)}</button>
        </div>
      </div>

      {/* Payment Modal */}
      {showPay && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl w-full max-w-md p-6">
            <h2 className="text-xl font-bold mb-4">💰 Cobro</h2>
            <div className="grid grid-cols-3 gap-2 mb-4">
              {[{v:'efectivo',l:'💵 Efectivo'},{v:'tarjeta',l:'💳 Tarjeta'},{v:'transferencia',l:'🏦 Transfer.'}].map(m => (
                <button key={m.v} onClick={()=>setPayMethod(m.v)} className={`py-2.5 rounded-xl text-sm font-semibold border-2 transition ${payMethod===m.v?'border-primary-600 bg-primary-50 text-primary-700':'border-gray-200'}`}>{m.l}</button>
              ))}
            </div>
            <div className="bg-gray-50 rounded-xl p-3 mb-3"><div className="flex justify-between text-lg font-bold"><span>Total</span><span>{curr}{total.toFixed(2)}</span></div></div>
            {payMethod==='efectivo' && (
              <div className="mb-3">
                <label className="text-sm font-medium mb-1 block">¿Cuánto entrega el cliente?</label>
                <input type="number" step="0.01" value={amountPaid} onChange={e=>setAmountPaid(e.target.value)} className="w-full px-4 py-3 rounded-xl border outline-none text-lg" autoFocus />
                {parseFloat(amountPaid)>=total && <p className="text-green-600 font-semibold mt-1">Vuelto: {curr}{(parseFloat(amountPaid)-total).toFixed(2)}</p>}
              </div>
            )}
            <div className="flex gap-3 mt-4">
              <button onClick={completeSale} className="flex-1 py-3 bg-green-600 text-white font-bold rounded-xl">✓ Confirmar</button>
              <button onClick={()=>setShowPay(false)} className="px-6 py-3 bg-gray-100 rounded-xl font-semibold">Cancelar</button>
            </div>
          </div>
        </div>
      )}

      {/* Sale Complete */}
      {showSaleOk && saleResult && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl w-full max-w-sm p-8 text-center">
            <div className="text-5xl mb-4">✅</div>
            <h2 className="text-2xl font-bold mb-2">¡Venta Exitosa!</h2>
            <p className="text-3xl font-bold text-primary-600">{curr}{saleResult.total.toFixed(2)}</p>
            {saleResult.method==='efectivo' && saleResult.change>0 && <p className="text-lg text-green-600 font-semibold mt-1">Vuelto: {curr}{saleResult.change.toFixed(2)}</p>}
            <div className="flex gap-3 mt-6">
              <button onClick={printTicket} className="flex-1 py-2.5 bg-gray-800 text-white font-bold rounded-xl">🖨️ Imprimir Ticket</button>
              <button onClick={()=>{setShowSaleOk(false);setSaleResult(null)}} className="flex-1 py-2.5 bg-primary-600 text-white font-bold rounded-xl">Nueva Venta</button>
            </div>
          </div>
        </div>
      )}

      {/* Scanner */}
      {showScanner && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl w-full max-w-md p-6 text-center">
            <h2 className="text-xl font-bold mb-4">📱 Escáner de Código</h2>
            <div className="bg-black rounded-2xl h-40 flex items-center justify-center mb-4 relative"><div className="absolute w-48 h-0.5 bg-red-500 animate-pulse"></div><span className="text-white text-sm">Apunta al código de barras</span></div>
            <div className="flex gap-2 mb-4">
              <input placeholder="O escribe el código..." className="flex-1 px-3 py-2 border rounded-lg font-mono" onKeyDown={e=>{if(e.key==='Enter'){const code=(e.target as HTMLInputElement).value;const p=products.find(x=>x.barcode===code);if(p){addToCart(p);setShowScanner(false)}}}} />
            </div>
            <button onClick={()=>setShowScanner(false)} className="px-6 py-2 bg-gray-200 rounded-xl font-semibold">Cerrar</button>
          </div>
        </div>
      )}
    </div>
  )
}
